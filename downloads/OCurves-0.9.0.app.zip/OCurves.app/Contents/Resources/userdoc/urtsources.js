var urtsources =
[
    [ "Real Time Source XML Specification", "urtformat.html", [
      [ "<tt>connection</tt>", "urtformat.html#xmlconnection", null ],
      [ "<tt>serial</tt>", "urtformat.html#xmlserial", null ],
      [ "<tt>network</tt>", "urtformat.html#xmlnetwork", null ],
      [ "<tt>buffer</tt>", "urtformat.html#xmlbuffer", null ],
      [ "<tt>time</tt>", "urtformat.html#xmltime", null ],
      [ "<tt>comms</tt>", "urtformat.html#xmlcomms", null ],
      [ "<tt>onconnect</tt> and <tt>ondisconnect</tt>", "urtformat.html#xmlconnect", null ],
      [ "<tt>headings</tt> and <tt>receive</tt>", "urtformat.html#xmlreceive", null ],
      [ "<tt>struct</tt>", "urtformat.html#xmlstruct", null ]
    ] ],
    [ "Real Time Source XML Examples", "urtex.html", null ]
];